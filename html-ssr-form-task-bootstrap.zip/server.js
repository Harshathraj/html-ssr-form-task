const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// In-memory temporary storage
let submissions = [];

app.get('/', (req, res) => {
    res.render('form');
});

app.post('/submit', (req, res) => {
    const { name, email, age, gender } = req.body;

    // Server-side validation
    if (!name || !email || !age || !gender || age < 1 || age > 120) {
        return res.status(400).send("Invalid input. Please go back and try again.");
    }

    // Store data temporarily
    submissions.push({ name, email, age, gender });
    res.render('response', { name, email, age, gender });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
